<?php
declare(strict_types=1);

namespace App\Policy;

use App\Model\Table\ArticleTable;
use Authorization\IdentityInterface;

/**
 * Article policy
 */
class ArticleTablePolicy
{
}
