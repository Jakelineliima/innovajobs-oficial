<main class="main container inicial ">
  <div class="div">
    <section class="session">

      <p class="p">
        <b>
          Conheça sua nova vida profissional.
        </b>
      </p>
      <p class="p">
        Na Innova Jobs temos vagas para todas as áreas.
      </p>

    </section>
    <section class="scimg">
      <img class="img" src="../img/Group 148.png" alt="" />
    </section>
  </div>
  <div class="div" style="margin: 53px 0px 40px auto;">
    <section class="session">
      <p class="p">
        <b>
          Fique por dentro das novidades do seu setor.
        </b>
      </p>
      <p class="p pjust">
        Oferecemos vagas inclusivas e com acessibilidade, e também para você que
        está iniciando no mercado de trabalho, Innova Jobs oferece espaço para
        todos em todas as pessoas em diversas áreas.
      </p>
    </section>
    <section class="scimg">
      <img class="img" src="../img/Group 146.png" alt="" />
    </section>
  </div>
</main>