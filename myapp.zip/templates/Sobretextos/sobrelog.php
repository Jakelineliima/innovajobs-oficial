
<head>
    <?= $this->fetch('css') ?>
    <?= $this->Html->css(['sobre']) ?>
</head>
<main class="main container sobre">
  <div class="divsobre">
    <section class="sessionsob">
      <p class="p">
        <b>
          Innova Jobs é uma plataforma de vagas de empregos para mão de obra operacional 100% gratuita.
        </b>
      </p>
      <p class="psob p">
        Nossa proposta é promover um encontro entre os melhores profissionais com as vagas mais relevantes do mercado, contribuindo para uma maior satisfação profissional.
      </p>
      <img class="img imgsob" src="../img/2-2.png" alt="" />
    </section>
   
  </div>
  <div class="divsobre">
    <section class="sessionsob">
      <p class="psob p">
        <b>
          OPORTUNIDADES DO MERCADO PARA MÃO DE OBRA OPERACIONAL.
        </b>
      </p>
      <p class="psob p">
        Muitos dos nossos candidatos conquistam o primeiro emprego ou mudam de área com as vagas cadastradas em nossa plataforma.
        Priorizamos vagas inclusivas e com acessibilidade, garantindo maior qualidade de vida profissional.
      </p>
      <img class="img imgsob" src="../img/3-3.png" alt="" />
    </section>

  </div>
</main>